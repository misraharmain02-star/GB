import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const PORT = 3000;

// Resolve __dirname in ES Modules context
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend assets
app.use(express.static(process.cwd()));
app.use('/images', express.static(path.join(process.cwd(), 'images')));

// Production-ready mock API routes for MongoDB/JWT simulation
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'GlamBook Node/Express Server running smoothly.' });
});

// Mock database endpoints for frontend integration if needed
app.get('/api/artists', (req, res) => {
  res.json({
    success: true,
    data: [
      { id: 'artist-1', name: 'Samira Khan', city: 'San Francisco', category: 'makeup', pricing: 120, rating: 4.9 },
      { id: 'artist-2', name: 'Elena Gilbert', city: 'Los Angeles', category: 'hairsalon', pricing: 150, rating: 4.8 },
      { id: 'artist-3', name: 'Anika Sen', city: 'San Francisco', category: 'mehendi', pricing: 90, rating: 4.7 }
    ]
  });
});

// Handle SPA route fallback using clean middleware (avoids path-to-regexp string wildcard compilation errors in newer Express/Node engines)
app.use((req, res, next) => {
  if (req.path.startsWith('/api') || req.path.includes('.')) {
    return next();
  }
  res.sendFile(path.join(process.cwd(), 'index.html'));
});

// Export app for serverless platforms like Vercel
export default app;

// Start listening if run directly (e.g., local development, Docker, Cloud Run)
if (!process.env.VERCEL) {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[GlamBook Express Backend] Running at http://localhost:${PORT}`);
  });
}

