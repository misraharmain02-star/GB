# GlamBook Installation & Folder Architecture Guide

This file provides comprehensive guidelines on installing, running, and scaling the modern GlamBook Beauty Marketplace.

---

## 1. Directory Structure Organization
Your production GlamBook project should follow the optimized architecture below:

```text
glambook/
├── backend/
│   ├── server.js              # Express.js Application entry-point
│   ├── routes/                # REST API Endpoint Routers
│   │   ├── auth.js            # JWT Registrations & Logins
│   │   ├── artists.js         # Specialist directory operations
│   │   └── bookings.js        # Diary reservations & payments
│   ├── models/                # MongoDB Mongoose schemas
│   │   ├── User.js
│   │   ├── Artist.js
│   │   ├── Booking.js
│   │   └── Review.js
│   └── config/
│       └── db.js              # MongoDB Atlas connection setup
│
├── frontend/                  # Static assets (copied to build folder)
│   ├── index.html             # Single Page Application core frame
│   ├── style.css              # Custom styled overlays & transitions
│   ├── script.js              # State management & dynamic DOM mapping
│   └── images/                # High-definition visual assets
│       ├── glambook_logo.png
│       ├── glambook_pink_hero.png
│       ├── bridal_makeup.png
│       ├── hair_stylist.png
│       └── nails_care.png
│
├── package.json               # Dependancy specifications & build scripts
└── README.md                  # Project overview documentation
```

---

## 2. Required Images Catalog
To maintain the premium beauty studio vibe, verify the following files are present inside the `/images` folder:

1. **`glambook_logo.png`**  
   *Description:* Highly customized white/pink logo showing a crown badge.  
   *Fallback:* Beautiful gradient lettermark or standard icon.
   
2. **`glambook_pink_hero.png`**  
   *Description:* Stunning cosmetics flatlay and bridal makeup layout styled on a soft rose background.  
   *Fallback:* Sourced from Unsplash bridal assets.

3. **`bridal_makeup.png` & `makeup_palette.png`**  
   *Description:* Transparent makeup products or a high-contrast bridal look used inside listing portfolios.

4. **`hair_stylist.png` & `nails_care.png`**  
   *Description:* High-contrast hairstyling tools or nail art visuals for service cards.

---

## 3. Step-by-Step Installation Instructions

Follow these exact commands to install and start GlamBook on your local computer or production container:

### Prerequisites
- **Node.js** (v18.0.0 or higher recommended)
- **NPM** (v9.0.0 or higher) / **Yarn**
- **MongoDB** local instance or **MongoDB Atlas Connection URI**

### 1. Download and Decompress
Extract the GlamBook project ZIP file or git clone the repository:
```bash
git clone https://github.com/yourusername/glambook.git
cd glambook
```

### 2. Install Project Dependencies
Run npm install inside the project root folder. This installs Express, path, and all other static asset servers:
```bash
npm install
```

### 3. Setup Environment Variables
Create a file named `.env` in the root folder and add your sensitive production parameters:
```env
PORT=3000
MONGODB_URI=mongodb+srv://your_user:your_password@cluster0.mongodb.net/glambook
JWT_SECRET=your_glowing_pink_secret_key
NODE_ENV=production
```

### 4. Execute the Deep-Linting & Compiling Steps
To verify that all syntaxes are clean and complete:
```bash
npm run build
```

### 5. Launch the Web Application Backend
To start the live server:
```bash
# Start in developmental hot-reloader mode
npm run dev

# Start in high-speed Production mode
npm start
```

Now, open your preferred web browser and navigate code to:
**`http://localhost:3000`** to experience the glorious GlamBook marketplace!
