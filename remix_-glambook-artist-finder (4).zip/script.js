// GlamBook Pure Static Client-Side Engine State

// 1. CHRONOLOGY DEFAULT DATASETS (Seeding mockDb structures)
const DEFAULT_USERS = [
  { id: 'cust-1', name: 'Elena Gilbert', email: 'elena@example.com', password: 'password', role: 'customer', profileImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150' },
  { id: 'artist-1', name: 'Samira Khan', email: 'samira@example.com', password: 'password', role: 'artist', profileImage: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150' },
  { id: 'artist-2', name: 'Anika Sharma', email: 'anika@example.com', password: 'password', role: 'artist', profileImage: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150' },
  { id: 'artist-3', name: 'Zoe Sterling', email: 'zoe@example.com', password: 'password', role: 'artist', profileImage: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150' },
  { id: 'admin-1', name: 'GlamBook Operator', email: 'admin@example.com', password: 'password', role: 'admin', profileImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150' }
];

const DEFAULT_ARTISTS = [
  {
    artistId: 'artist-1',
    name: 'Samira Khan',
    category: 'makeup',
    city: 'San Francisco',
    experience: 6,
    pricing: 150,
    availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    bio: 'Certified Cosmetics specialist focusing on bridal airbrush makeovers, organic glowing glitz treatments, and customized high-fashion makeup.',
    verified: true,
    portfolio: [
      '/images/bridal_makeup.png',
      '/images/makeup_palette.png',
      '/images/bridal_mehendi_banner.png'
    ]
  },
  {
    artistId: 'artist-2',
    name: 'Anika Sharma',
    category: 'mehendi',
    city: 'Los Angeles',
    experience: 8,
    pricing: 120,
    availability: ['Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    bio: 'Professional mehendi tattoo illustrator. Intricate modern arabesque curves, natural safe organic henna, and traditional bridal visual highlights.',
    verified: true,
    portfolio: [
      '/images/mehndi_henna.png',
      '/images/bridal_mehendi_banner.png'
    ]
  },
  {
    artistId: 'artist-3',
    name: 'Zoe Sterling',
    category: 'hairsalon',
    city: 'San Francisco',
    experience: 5,
    pricing: 130,
    availability: ['Thursday', 'Friday', 'Saturday', 'Sunday'],
    bio: 'Bespoke curled wedding blowouts, intricate braids arrangements, and texturized updos designed to survive high-humidity dancefloors.',
    verified: false,
    portfolio: [
      '/images/glambook_minimal_hero.png',
      '/images/glambook_pink_hero.png'
    ]
  }
];

const DEFAULT_SERVICES = [
  { serviceId: 'srv-1', artistId: 'artist-1', serviceName: 'Bridal HD Cosmetics Styling', price: 250 },
  { serviceId: 'srv-2', artistId: 'artist-1', serviceName: 'Natural Engagement Blowout Glow', price: 150 },
  { serviceId: 'srv-3', artistId: 'artist-2', serviceName: 'Traditional Heavy Royal Henna', price: 180 },
  { serviceId: 'srv-4', artistId: 'artist-2', serviceName: 'Minimalist Floral Arabian Sachet', price: 90 },
  { serviceId: 'srv-5', artistId: 'artist-3', serviceName: 'Bespoke Curled Updo Hairstyling', price: 160 },
  { serviceId: 'srv-6', artistId: 'artist-3', serviceName: 'Voluminous Half-Up Half-Down Braids', price: 110 }
];

const DEFAULT_BOOKINGS = [
  {
    bookingId: 'book-1',
    customerId: 'cust-1',
    customerName: 'Elena Gilbert',
    artistId: 'artist-1',
    artistName: 'Samira Khan',
    serviceId: 'srv-1',
    serviceName: 'Bridal HD Cosmetics Styling',
    bookingDate: '2026-06-15',
    bookingTime: '11:00 AM',
    bookingStatus: 'confirmed',
    totalAmount: 250,
    notes: 'Bride dress is light champagne pink. Prefer soft glam cosmetics styling with focus on lashes.'
  },
  {
    bookingId: 'book-2',
    customerId: 'cust-1',
    customerName: 'Elena Gilbert',
    artistId: 'artist-2',
    artistName: 'Anika Sharma',
    serviceId: 'srv-4',
    serviceName: 'Minimalist Floral Arabian Sachet',
    bookingDate: '2026-06-20',
    bookingTime: '03:00 PM',
    bookingStatus: 'pending',
    totalAmount: 90,
    notes: 'Test session for bridesmaids.'
  }
];

const DEFAULT_REVIEWS = [
  { reviewId: 'rev-1', customerId: 'cust-1', customerName: 'Elena Gilbert', artistId: 'artist-1', rating: 5, comment: 'Absolutely mesmerizing cosmetics style! Samira was professional, punctual, and knew exactly how to work with dry skin levels.', createdAt: '2026-06-01T12:00:00Z' }
];

const DEFAULT_PAYMENTS = [
  { paymentId: 'pay-1', bookingId: 'book-1', amount: 250, paymentStatus: 'successful', paymentMethod: 'Card', createdAt: '2026-06-05T09:12:00Z' }
];

const DEFAULT_NOTIFICATIONS = [
  { id: 'notif-1', userId: 'cust-1', title: 'Appointment Confirmed', message: 'Samira Khan accepted and locked your Bridal HD Cosmetics booking on 2026-06-15!', read: false, createdAt: '2026-06-05T10:00:00Z' },
  { id: 'notif-2', userId: 'artist-1', title: 'New Appointment Booked', message: 'Elena Gilbert booked Natural Engagement Blowout for 2026-06-24!', read: true, createdAt: '2026-06-05T09:30:00Z' }
];

// 2. HELPER DATA QUERIES
function getCollection(key, defaults) {
  const data = localStorage.getItem('glambook_' + key);
  if (!data) {
    localStorage.setItem('glambook_' + key, JSON.stringify(defaults));
    return defaults;
  }
  return JSON.parse(data);
}

function saveCollection(key, data) {
  localStorage.setItem('glambook_' + key, JSON.stringify(data));
}

let db = {
  getUsers: () => getCollection('users', DEFAULT_USERS),
  saveUsers: (u) => saveCollection('users', u),
  getArtists: () => getCollection('artists', DEFAULT_ARTISTS),
  saveArtists: (a) => saveCollection('artists', a),
  getServices: () => getCollection('services', DEFAULT_SERVICES),
  saveServices: (s) => saveCollection('services', s),
  getBookings: () => getCollection('bookings', DEFAULT_BOOKINGS),
  saveBookings: (b) => saveCollection('bookings', b),
  getReviews: () => getCollection('reviews', DEFAULT_REVIEWS),
  saveReviews: (r) => saveCollection('reviews', r),
  getPayments: () => getCollection('payments', DEFAULT_PAYMENTS),
  savePayments: (p) => saveCollection('payments', p),
  getNotifications: () => getCollection('notifications', DEFAULT_NOTIFICATIONS),
  saveNotifications: (n) => saveCollection('notifications', n),
  getSavedArtists: () => getCollection('saved_artists', [])
};

// 3. SECURED STATE INITIALIZATION
window.user = JSON.parse(localStorage.getItem('glambook_user')) || null;
window.token = localStorage.getItem('glambook_token') || null;
window.currentPage = 'home';
window.currentPageParams = null;

// Dashboard tabs states
let currentCustTab = 'bookings';
let currentArtistTab = 'requests';
let currentAdminTab = 'analytics';

// Simple directory search parameters
let filterState = {
  search: '',
  category: '',
  city: '',
  price: 500,
  rating: ''
};

// 4. CENTRAL APPLET PAGE NAVIGATION MODULE (Router Swapping)
window.navigateTo = function(page, params = null) {
  window.currentPage = page;
  window.currentPageParams = params;
  
  // Hide all template sections
  document.querySelectorAll('.view-panel').forEach(p => p.classList.add('hidden'));

  // Highlight selected view wrapper
  const container = document.getElementById('view-' + page);
  if (container) {
    container.classList.remove('hidden');
  }

  // Back up scroll states
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Update navbar layout
  updateHeaderUI();

  // Route specific dynamic lists rendering
  if (page === 'home') {
    renderHome();
  } else if (page === 'artists-listing') {
    if (params && params.category) {
      filterState.category = params.category;
      const el = document.getElementById('filter-category');
      if (el) el.value = params.category;
    }
    applyFilters();
  } else if (page === 'artist-profile') {
    renderProfile(params?.artistId);
  } else if (page === 'booking') {
    renderBooking(params?.artistId, params?.serviceId);
  } else if (page === 'customer-dashboard') {
    renderCustomerDashboard();
  } else if (page === 'artist-dashboard') {
    renderArtistDashboard();
  } else if (page === 'admin-dashboard') {
    renderAdminDashboard();
  } else if (page === 'notifications-list') {
    renderNotifications();
  }

  // Refresh Lucide icon renderings helper
  if (window.lucide) {
    window.lucide.createIcons();
  }
};

window.navigateToDashboard = function() {
  if (!window.user) {
    addToast('Please sign in to access consoles.', 'info');
    navigateTo('login');
    return;
  }
  if (window.user.role === 'customer') {
    navigateTo('customer-dashboard');
  } else if (window.user.role === 'artist') {
    navigateTo('artist-dashboard');
  } else if (window.user.role === 'admin') {
    navigateTo('admin-dashboard');
  }
};

// 5. THEME SWITCHER CONTROLS
window.toggleTheme = function() {
  const html = document.documentElement;
  if (html.classList.contains('dark')) {
    html.classList.remove('dark');
    localStorage.setItem('glambook_theme', 'light');
    addToast('Set to Elegant Light palette.', 'success');
  } else {
    html.classList.add('dark');
    localStorage.setItem('glambook_theme', 'dark');
    addToast('Set to Twilight Cozy dark canvas.', 'success');
  }
};

function initTheme() {
  const saved = localStorage.getItem('glambook_theme');
  const html = document.documentElement;
  if (saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    html.classList.add('dark');
  } else {
    html.classList.remove('dark');
  }
}

// 6. GLOBAL TOAST MICRO-SYSTEM PORTALS
window.addToast = function(message, type = 'info') {
  const portal = document.getElementById('toast-overlay-portal');
  if (!portal) return;

  const toast = document.createElement('div');
  toast.className = 'animate-slide-in pointer-events-auto flex items-center justify-between p-4 bg-white dark:bg-zinc-900 border-l-4 shadow-xl rounded-xl transition-all duration-300';
  
  if (type === 'success') {
    toast.className += ' border-emerald-500 text-emerald-850 dark:text-emerald-350';
  } else if (type === 'error') {
    toast.className += ' border-rose-500 text-rose-850 dark:text-rose-350 animate-shake';
  } else if (type === 'info') {
    toast.className += ' border-violet-500 text-violet-850 dark:text-violet-300';
  } else {
    toast.className += ' border-amber-500 text-amber-850 dark:text-amber-300';
  }

  toast.innerHTML = `
    <div class="flex items-center space-x-2">
      <span class="text-sm font-bold">${message}</span>
    </div>
    <button onclick="this.parentElement.remove()" class="ml-4 font-bold text-zinc-400 hover:text-zinc-650 shrink-0 text-sm focus:outline-none">&times;</button>
  `;

  portal.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
};

// 7. HEADER NAVBAR STATE CONTROLLERS
function updateHeaderUI() {
  const unregistered = document.getElementById('auth-unregistered');
  const registered = document.getElementById('auth-registered');
  const navDashboard = document.getElementById('nav-dashboard');
  const bell = document.getElementById('notif-bell');

  if (window.user) {
    unregistered.classList.add('hidden');
    registered.classList.remove('hidden');
    navDashboard.classList.remove('hidden');
    bell.classList.remove('hidden');

    document.getElementById('avatar-img').src = window.user.profileImage;
    document.getElementById('user-display-name').textContent = window.user.name;
    document.getElementById('user-display-role').textContent = window.user.role === 'customer' ? 'client' : window.user.role;
    
    // Set notification unread count badger
    const notifs = db.getNotifications().filter(n => n.userId === window.user.id && !n.read);
    const badge = document.getElementById('notif-badge');
    badge.textContent = notifs.length;
    if (notifs.length > 0) {
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  } else {
    unregistered.classList.remove('hidden');
    registered.classList.add('hidden');
    navDashboard.classList.add('hidden');
    bell.classList.add('hidden');
  }
}

// 8. LOGOUT ACTION
window.logout = function() {
  window.user = null;
  window.token = null;
  localStorage.removeItem('glambook_user');
  localStorage.removeItem('glambook_token');
  addToast('Successfully signed out of workspace logs.', 'success');
  navigateTo('home');
};

// 9. PREDEFINED SIMULATED CREDENTIAL LOGINS
window.loginPredefined = function(id) {
  const u = db.getUsers().find(x => x.id === id);
  if (u) {
    window.user = u;
    window.token = 'mock_jwt_session_token_' + u.id;
    localStorage.setItem('glambook_user', JSON.stringify(u));
    localStorage.setItem('glambook_token', window.token);
    addToast(`Connected as ${u.name}!`, 'success');
    navigateToDashboard();
  }
};

// 10. AUTHENTICATION PAGES SUBMISSIONS
window.submitLogin = function(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const pass = document.getElementById('login-password').value;

  const found = db.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!found) {
    addToast('Credentials do not match.', 'error');
    return;
  }
  if (found.blocked) {
    addToast('Account blocked by systemic operators.', 'error');
    return;
  }
  if (found.password !== pass) {
    addToast('Incorrect password credentials.', 'error');
    return;
  }

  window.user = found;
  window.token = 'mock_jwt_session_token_' + found.id;
  localStorage.setItem('glambook_user', JSON.stringify(found));
  localStorage.setItem('glambook_token', window.token);
  
  addToast(`Welcome back, ${found.name}!`, 'success');
  navigateToDashboard();
};

window.toggleSignupRoleBox = function(role) {
  const customBox = document.getElementById('signup-role-customer-box');
  const artistBox = document.getElementById('signup-role-artist-box');
  const details = document.getElementById('signup-artist-details');

  if (role === 'customer') {
    customBox.className = 'border-2 rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer hover:border-violet-305 transition-all text-center';
    artistBox.className = 'border rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer hover:border-violet-305 transition-all text-center';
    details.classList.add('hidden');
  } else {
    customBox.className = 'border rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer hover:border-violet-305 transition-all text-center';
    artistBox.className = 'border-2 rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer hover:border-violet-305 transition-all text-center';
    details.classList.remove('hidden');
  }
};

window.submitSignup = function(e) {
  e.preventDefault();
  const name = document.getElementById('signup-name').value.trim();
  const email = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-password').value;
  const role = document.querySelector('input[name="signup-role"]:checked').value;

  let users = db.getUsers();
  if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    addToast('Email credentials already configured.', 'error');
    return;
  }

  const userId = 'user-' + Date.now();
  const newUser = {
    id: userId,
    name,
    email,
    password,
    role,
    profileImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
  };

  users.push(newUser);
  db.saveUsers(users);

  if (role === 'artist') {
    const city = document.getElementById('signup-city').value;
    const category = document.getElementById('signup-category').value;
    const experience = Number(document.getElementById('signup-experience').value) || 2;
    const pricing = Number(document.getElementById('signup-pricing').value) || 80;

    let artists = db.getArtists();
    const newArtist = {
      artistId: userId,
      name,
      category,
      city,
      experience,
      pricing,
      availability: ['Monday', 'Wednesday', 'Friday'],
      bio: `Professional ${category} based in ${city} with ${experience} years of bridal cosmetics expertise. Ready for custom scheduling.`,
      verified: false,
      portfolio: ['/images/glambook_minimal_hero.png']
    };
    artists.push(newArtist);
    db.saveArtists(artists);

    // Seed default services
    let services = db.getServices();
    services.push({ serviceId: 'srv-' + Date.now() + '-1', artistId: userId, serviceName: 'Signature Full Makeover', price: pricing });
    services.push({ serviceId: 'srv-' + Date.now() + '-2', artistId: userId, serviceName: 'Express Touch-Up Session', price: Math.round(pricing * 0.6) });
    db.saveServices(services);
  }

  window.user = newUser;
  window.token = 'mock_jwt_session_token_' + userId;
  localStorage.setItem('glambook_user', JSON.stringify(newUser));
  localStorage.setItem('glambook_token', window.token);

  addToast(`Registered coordinates successfully!`, 'success');
  navigateToDashboard();
};

window.submitForgotPassword = function(e) {
  e.preventDefault();
  const email = document.getElementById('forgot-email').value.trim();
  addToast(`Reset tokens generated for ${email}. Access login codes in sandbox diaries.`, 'success');
  navigateTo('login');
};

// 11. HOMEPAGE EXPLORER DISPLAY RENDER
function renderHome() {
  const container = document.getElementById('home-featured-grid');
  if (!container) return;

  const artists = db.getArtists().filter(a => a.verified).slice(0, 3);
  container.innerHTML = artists.map(a => {
    const rating = db.getReviews().filter(r => r.artistId === a.artistId);
    const avg = rating.length ? (rating.reduce((acc, current) => acc + current.rating, 0) / rating.length).toFixed(1) : '4.8';
    const u = db.getUsers().find(user => user.id === a.artistId);
    const avatar = u?.profileImage || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150';
    
    return `
      <div onclick="navigateTo('artist-profile', {artistId:'${a.artistId}'})" class="group cursor-pointer border border-rose-100/50 rounded-3xl overflow-hidden bg-white hover:-translate-y-1.5 transition duration-300 dark:bg-zinc-900 dark:border-zinc-805 shadow-sm">
        <div class="h-44 overflow-hidden relative">
          <img src="${a.portfolio[0] || '/images/glambook_minimal_hero.png'}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
          <span class="absolute top-3 left-3 rounded bg-white/90 backdrop-blur-md px-2.5 py-0.5 text-[9px] font-bold text-violet-750 uppercase dark:bg-zinc-900/90 dark:text-violet-300">${a.category}</span>
          <!-- Professional overlapping floating avatar -->
          <div class="absolute -bottom-3 right-4 h-9 w-9 rounded-full border-2 border-white bg-white shadow-md overflow-hidden z-20">
            <img src="${avatar}" class="h-full w-full object-cover select-none" />
          </div>
        </div>
        <div class="p-5 pt-6 text-xs text-left space-y-1.5 transition">
          <div class="flex items-center justify-between">
            <h3 class="font-serif text-base font-extrabold group-hover:text-violet-605 transition">${a.name}</h3>
            <span class="flex items-center space-x-0.5 text-amber-500 font-bold"><span>★</span><span>${avg}</span></span>
          </div>
          <p class="text-zinc-400 font-medium">${a.city} &bull; ${a.experience} Years Exp</p>
          <div class="pt-3 border-t flex justify-between items-center text-zinc-500 dark:border-zinc-850">
            <span>Base pricing:</span>
            <span>Est <span class="font-bold text-violet-605">$${a.pricing}/hr</span></span>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

window.handleHomeSearch = function() {
  const words = document.getElementById('home-search-input').value.trim();
  const city = document.getElementById('home-city-select').value;
  
  filterState.search = words;
  filterState.city = city;

  // Sync back input states
  const flSearch = document.getElementById('filter-search');
  if (flSearch) flSearch.value = words;
  const flCity = document.getElementById('filter-city');
  if (flCity) flCity.value = city;

  navigateTo('artists-listing');
};

// 12. SPECIALIST DIRECTORY (Search Directory Filters)
window.updatePriceSlider = function(val) {
  document.getElementById('price-slider-badge').textContent = '$' + val + '/hr';
  filterState.price = Number(val);
  applyFilters();
};

window.resetFilters = function() {
  filterState = { search: '', category: '', city: '', price: 500, rating: '' };
  
  document.getElementById('filter-search').value = '';
  document.getElementById('filter-category').value = '';
  document.getElementById('filter-city').value = '';
  document.getElementById('filter-price').value = 500;
  document.getElementById('price-slider-badge').textContent = '$500/hr';
  document.querySelectorAll('input[name="filter-rating"]').forEach(r => r.checked = r.value === '');

  applyFilters();
};

window.applyFilters = function() {
  const searchEl = document.getElementById('filter-search');
  const catEl = document.getElementById('filter-category');
  const cityEl = document.getElementById('filter-city');
  const rSelected = document.querySelector('input[name="filter-rating"]:checked');

  filterState.search = searchEl ? searchEl.value.trim().toLowerCase() : '';
  filterState.category = catEl ? catEl.value : '';
  filterState.city = cityEl ? cityEl.value : '';
  filterState.rating = rSelected ? rSelected.value : '';

  if (filterState.city) {
    synthesizeArtistsForCity(filterState.city);
  }

  const artists = db.getArtists();
  const filtered = artists.filter(a => {
    // Search words
    const matchesSearch = !filterState.search || a.name.toLowerCase().includes(filterState.search) || a.bio.toLowerCase().includes(filterState.search);
    const matchesCategory = !filterState.category || a.category === filterState.category;
    const matchesCity = !filterState.city || a.city === filterState.city;
    const matchesPrice = a.pricing <= filterState.price;

    // Calculate ratings average
    const rates = db.getReviews().filter(r => r.artistId === a.artistId);
    const avg = rates.length ? rates.reduce((acc, curr) => acc + curr.rating, 0) / rates.length : 4.8;
    const matchesRating = !filterState.rating || avg >= Number(filterState.rating);

    return matchesSearch && matchesCategory && matchesCity && matchesPrice && matchesRating;
  });

  const countBadge = document.getElementById('listing-results-count');
  const emptyState = document.getElementById('listing-empty-state');
  const grid = document.getElementById('listing-grid animate-fade-in');

  if (countBadge) countBadge.textContent = `Displaying ${filtered.length} verified results`;

  if (filtered.length === 0) {
    emptyState.classList.remove('hidden');
    grid.innerHTML = '';
  } else {
    emptyState.classList.add('hidden');
    grid.innerHTML = filtered.map(a => {
      const rating = db.getReviews().filter(r => r.artistId === a.artistId);
      const avg = rating.length ? (rating.reduce((acc, curr) => acc + curr.rating, 0) / rating.length).toFixed(1) : '4.8';
      const u = db.getUsers().find(user => user.id === a.artistId);
      const avatar = u?.profileImage || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150';
      
      return `
        <div onclick="navigateTo('artist-profile', {artistId:'${a.artistId}'})" class="group cursor-pointer border rounded-3xl overflow-hidden bg-white hover:-translate-y-1 transition dark:bg-zinc-900 border-rose-100/50 dark:border-zinc-805 shadow-sm">
          <div class="h-40 overflow-hidden relative">
            <img src="${a.portfolio[0] || '/images/glambook_minimal_hero.png'}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
            <span class="absolute top-2.5 left-2.5 rounded bg-white/90 backdrop-blur-md px-2 py-0.5 text-[8px] font-bold text-violet-750 uppercase dark:bg-zinc-900/90 dark:text-violet-300">${a.category}</span>
            <!-- Professional overlapping floating avatar -->
            <div class="absolute -bottom-3 right-4 h-9 w-9 rounded-full border-2 border-white bg-white shadow-md overflow-hidden z-20">
              <img src="${avatar}" class="h-full w-full object-cover select-none" />
            </div>
          </div>
          <div class="p-5 pt-6 text-xs text-left space-y-1.5">
            <div class="flex items-center justify-between">
              <h3 class="font-serif text-sm font-bold group-hover:text-violet-605 transition">${a.name}</h3>
              <span class="flex items-center space-x-0.5 text-amber-500 font-bold"><span>★</span><span>${avg}</span></span>
            </div>
            <p class="text-zinc-400 font-medium">${a.city} &bull; ${a.experience} Years Exp</p>
            <div class="pt-2 border-t flex justify-between items-center text-zinc-500 dark:border-zinc-805">
              <span>Base hourly Rate:</span>
              <span class="font-bold text-violet-605 text-sm">$${a.pricing}/hr</span>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }
};

// 13. SPECIALIST PROFILE DETAILS
function renderProfile(artistId) {
  const artist = db.getArtists().find(a => a.artistId === artistId);
  if (!artist) {
    addToast('Specialist data lookup failed.', 'error');
    navigateTo('artists-listing');
    return;
  }

  // Header nodes
  const matchingUser = db.getUsers().find(u => u.id === artist.artistId);
  document.getElementById('profile-picture').src = matchingUser?.profileImage || artist.portfolio[0] || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=250';
  document.getElementById('profile-name').textContent = artist.name;
  document.getElementById('profile-badge-category').textContent = artist.category;
  
  if (artist.verified) {
    document.getElementById('profile-badge-verified').classList.remove('hidden');
  } else {
    document.getElementById('profile-badge-verified').classList.add('hidden');
  }

  // Ratings calculation
  const reviews = db.getReviews().filter(r => r.artistId === artistId);
  const avg = reviews.length ? (reviews.reduce((acc, curr) => acc + curr.rating, 0) / reviews.length).toFixed(1) : '4.8';
  document.getElementById('profile-rating').textContent = `${avg} rating (${reviews.length} reviews)`;
  document.getElementById('profile-city').textContent = artist.city;
  document.getElementById('profile-experience').textContent = `${artist.experience} Years Experience`;

  // Bookmark save button render
  const saved = db.getSavedArtists();
  const isSaved = saved.includes(artistId);
  const saveBtn = document.getElementById('profile-btn-save');
  const saveText = document.getElementById('profile-btn-save-text');

  if (isSaved) {
    saveBtn.className = 'rounded-full px-6 py-2.5 text-xs font-bold flex items-center space-x-2 border border-rose-200 bg-rose-50 text-rose-700 cursor-pointer dark:bg-rose-950/20';
    saveText.textContent = 'Bookmarked';
  } else {
    saveBtn.className = 'rounded-full px-6 py-2.5 text-xs font-bold flex items-center space-x-2 border border-zinc-200 bg-white hover:bg-slate-50 text-zinc-700 cursor-pointer dark:bg-zinc-900 border-zinc-800 dark:text-zinc-300';
    saveText.textContent = 'Bookmark';
  }

  // Render services
  const srvs = db.getServices().filter(s => s.artistId === artistId);
  const catalog = document.getElementById('profile-catalog-list');
  if (srvs.length === 0) {
    catalog.innerHTML = '<p class="text-zinc-450 italic p-3">No dynamic treatment lists registered by provider yet.</p>';
  } else {
    catalog.innerHTML = srvs.map(s => `
      <div class="border rounded-2xl p-4.5 bg-zinc-50/50 flex justify-between items-center dark:bg-zinc-900/60 transition-colors border-rose-100/60 dark:border-zinc-805">
        <div class="text-left">
          <p class="font-bold text-zinc-900 dark:text-white leading-tight">${s.serviceName}</p>
          <p class="text-[10px] text-zinc-400 mt-1">Provider standard treat</p>
        </div>
        <div class="flex items-center space-x-4">
          <span class="font-black text-rose-600 text-sm">$${s.price}</span>
          <button onclick="navigateTo('booking', {artistId:'${artistId}', serviceId:'${s.serviceId}'})" class="rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold py-1.5 px-4 rounded transition active:scale-95 cursor-pointer">Reserve</button>
        </div>
      </div>
    `).join('');
  }

  // Render Portfolios
  const gallery = document.getElementById('profile-gallery-grid');
  gallery.innerHTML = artist.portfolio.map(img => `
    <div class="aspect-square rounded-2xl overflow-hidden shadow-sm hover:opacity-90 transition border border-zinc-100 dark:border-zinc-800">
      <img src="${img}" class="w-full h-full object-cover" />
    </div>
  `).join('');

  // Biography bio
  document.getElementById('profile-bio').textContent = artist.bio || 'No artist specifications bio stated.';

  // Badges availability days
  const badgeWrap = document.getElementById('profile-availability-badges');
  badgeWrap.innerHTML = artist.availability.map(day => `
    <span class="rounded bg-rose-50 border border-rose-100 px-2 py-0.5 text-[9px] font-semibold text-rose-700 dark:bg-rose-950/20 dark:border-zinc-800 dark:text-rose-450">${day}</span>
  `).join('');

  // Reviews Comments feed lists
  document.getElementById('profile-reviews-count').textContent = `Customer Reviews (${reviews.length})`;
  const reviewsUl = document.getElementById('profile-reviews-list');
  if (reviews.length === 0) {
    reviewsUl.innerHTML = '<p class="text-zinc-400 italic">No feedback comments logged for this cosmetics specialist.</p>';
  } else {
    reviewsUl.innerHTML = reviews.map(r => `
      <div class="border-b pb-3.5 space-y-1.5 dark:border-zinc-800">
        <div class="flex items-center justify-between">
          <p class="font-bold text-zinc-800 dark:text-zinc-200">${r.customerName}</p>
          <span class="text-amber-500 font-bold">★ ${r.rating}</span>
        </div>
        <p class="text-zinc-550 dark:text-zinc-450 leading-relaxed">${r.comment}</p>
      </div>
    `).join('');
  }
}

window.handleToggleSaveProfile = function() {
  const artistId = currentPageParams?.artistId;
  if (!artistId) return;

  let saved = db.getSavedArtists();
  const idx = saved.indexOf(artistId);
  if (idx > -1) {
    saved.splice(idx, 1);
    addToast('Bookmark removed.', 'info');
  } else {
    saved.push(artistId);
    addToast('Specialist portfolio page bookmarked.', 'success');
  }
  db.saveSavedArtists(saved);
  renderProfile(artistId);
};

// 14. CHECKOUT SCHEDULING CALENDAR OPERATIONS
function renderBooking(artistId, serviceId) {
  if (!window.token) {
    addToast('Please login to reserve services.', 'info');
    navigateTo('login');
    return;
  }

  const artist = db.getArtists().find(a => a.artistId === artistId);
  const srv = db.getServices().find(s => s.serviceId === serviceId);

  if (!artist || !srv) {
    addToast('Coordinates load error.', 'error');
    navigateTo('artists-listing');
    return;
  }

  // Summary bindings
  document.getElementById('checkout-service-name').textContent = srv.serviceName;
  document.getElementById('checkout-artist-name').textContent = artist.name;
  document.getElementById('checkout-service-price').textContent = '$' + srv.price;
  document.getElementById('checkout-total-price').textContent = '$' + srv.price;

  // Clear inputs
  document.getElementById('checkout-date').value = '';
  document.getElementById('checkout-date').min = new Date().toISOString().split('T')[0];
  document.getElementById('checkout-time').value = '';
  document.getElementById('checkout-notes').value = '';
  document.getElementById('pay-cardholder').value = window.user.name;
  document.getElementById('pay-number').value = '';
  document.getElementById('pay-expiry').value = '';
  document.getElementById('pay-cvv').value = '';
}

window.formatCardNumber = function(input) {
  let val = input.value.replace(/\D/g, '').substring(0, 16);
  let matches = val.match(/.{1,4}/g);
  input.value = matches ? matches.join(' ') : val;
};

window.formatCardExpiry = function(input) {
  let val = input.value.replace(/\D/g, '').substring(0, 4);
  if (val.length >= 2) {
    input.value = val.substring(0, 2) + '/' + val.substring(2);
  } else {
    input.value = val;
  }
};

window.submitCheckoutBooking = function(e) {
  e.preventDefault();
  
  const date = document.getElementById('checkout-date').value;
  const time = document.getElementById('checkout-time').value;
  const notes = document.getElementById('checkout-notes').value.trim();

  const cHolder = document.getElementById('pay-cardholder').value.trim();
  const cNum = document.getElementById('pay-number').value.replace(/\s+/g, '');
  const cExp = document.getElementById('pay-expiry').value;
  const cCvv = document.getElementById('pay-cvv').value;

  if (!date || !time) {
    addToast('Choose operational dates and times.', 'error');
    return;
  }
  if (cNum.length < 16 || cExp.length < 5 || cCvv.length < 3) {
    addToast('Verify sandbox metrics parameters details.', 'error');
    return;
  }

  const artistId = currentPageParams?.artistId;
  const srvId = currentPageParams?.serviceId;
  const artist = db.getArtists().find(a => a.artistId === artistId);
  const srv = db.getServices().find(s => s.serviceId === srvId);

  const bId = 'book-' + Date.now();
  
  // 1. Save Booking
  let bookings = db.getBookings();
  const bRow = {
    bookingId: bId,
    customerId: window.user.id,
    customerName: window.user.name,
    artistId,
    artistName: artist.name,
    serviceId: srvId,
    serviceName: srv.serviceName,
    bookingDate: date,
    bookingTime: time,
    bookingStatus: 'pending',
    totalAmount: srv.price,
    notes
  };
  bookings.push(bRow);
  db.saveBookings(bookings);

  // 2. Save Payment Row
  const payId = 'pay-' + Date.now();
  let payments = db.getPayments();
  payments.push({
    paymentId: payId,
    bookingId: bId,
    amount: srv.price,
    paymentStatus: 'successful',
    paymentMethod: 'Card',
    createdAt: new Date().toISOString()
  });
  db.savePayments(payments);

  // 3. Dispatch Notification to Artist
  let alerts = db.getNotifications();
  alerts.push({
    id: 'notif-' + Date.now(),
    userId: artistId,
    title: 'New Appointment Booked',
    message: `${window.user.name} booked ${srv.serviceName} for ${date} at ${time}.`,
    read: false,
    createdAt: new Date().toISOString()
  });
  db.saveNotifications(alerts);

  addToast('Demo Checkout complete!', 'success');

  // Load receipt screen parameters
  document.getElementById('success-receipt').textContent = payId;
  document.getElementById('success-service').textContent = srv.serviceName;
  document.getElementById('success-amount').textContent = '$' + srv.price;

  navigateTo('payment-success');
};

// 15. CLIENT CONSOLE SUB-MENUS
window.switchCustomerTab = function(tab) {
  currentCustTab = tab;
  
  // Toggles Class lists active styling
  const tabIds = ['bookings', 'saved', 'reviews', 'profile'];
  tabIds.forEach(id => {
    const el = document.getElementById('cust-tab-' + id);
    if (!el) return;
    if (id === tab) {
      el.className = 'w-full text-left p-3 rounded-xl font-bold transition flex items-center space-x-2 bg-violet-50 text-violet-750 dark:bg-zinc-805 dark:text-violet-300 cursor-pointer';
    } else {
      el.className = 'w-full text-left p-3 rounded-xl font-bold transition flex items-center space-x-2 hover:bg-slate-50 dark:hover:bg-zinc-850 cursor-pointer';
    }

    const panel = document.getElementById('cust-panel-' + id);
    if (panel) {
      if (id === tab) panel.classList.remove('hidden');
      else panel.classList.add('hidden');
    }
  });

  if (tab === 'bookings') renderCustomerBookings();
  else if (tab === 'saved') renderCustomerSaved();
  else if (tab === 'reviews') renderCustomerReviews();
};

function renderCustomerDashboard() {
  if (!window.user) return;
  document.getElementById('cust-dash-image').src = window.user.profileImage;
  document.getElementById('cust-dash-name').textContent = window.user.name;
  document.getElementById('cust-dash-email').textContent = window.user.email;

  const saved = db.getSavedArtists();
  document.getElementById('cust-dash-saved-count').textContent = saved.length + ' specialists';

  document.getElementById('edit-cust-image').value = window.user.profileImage;
  document.getElementById('edit-cust-name').value = window.user.name;

  switchCustomerTab(currentCustTab);
}

function renderCustomerBookings() {
  const container = document.getElementById('cust-bookings-list');
  const list = db.getBookings().filter(b => b.customerId === window.user.id);
  
  if (list.length === 0) {
    container.innerHTML = '<p class="text-zinc-400 italic py-6">Your agenda calendar list is currently empty.</p>';
    return;
  }

  container.innerHTML = list.map(b => {
    let statCls = 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400';
    if (b.bookingStatus === 'confirmed') statCls = 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-400';
    if (b.bookingStatus === 'completed') statCls = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400';
    if (b.bookingStatus === 'cancelled') statCls = 'bg-red-50 text-red-700 dark:bg-red-950/20 dark:text-red-400';

    const isReviewed = db.getReviews().some(r => r.customerId === window.user.id && r.artistId === b.artistId);

    return `
      <div class="border rounded-2xl bg-white p-5 dark:bg-zinc-900 border-rose-100/60 dark:border-zinc-805 shadow-sm text-left relative transition-colors">
        <div class="flex justify-between items-center mb-3">
          <span class="rounded px-2 py-0.5 text-[8px] font-black uppercase tracking-wider ${statCls}">${b.bookingStatus}</span>
          <span class="font-extrabold text-rose-600">$${b.totalAmount}</span>
        </div>
        <p class="font-serif text-sm font-black mb-1">${b.serviceName}</p>
        <p class="text-zinc-405 leading-none">Stylist: <span class="font-bold text-zinc-900 dark:text-zinc-200">${b.artistName}</span></p>
        <p class="text-[10px] text-zinc-400 mt-2">Reserved slot: ${b.bookingDate} at ${b.bookingTime}</p>
        ${b.notes ? `<p class="border-t pt-2 mt-2 text-[10px] text-zinc-500 italic dark:border-zinc-800">Preferences: "${b.notes}"</p>` : ''}
        
        <div class="mt-4 flex justify-end space-x-2 border-t pt-3 dark:border-zinc-800">
          ${b.bookingStatus === 'pending' || b.bookingStatus === 'confirmed' ? `
            <button onclick="cancelBooking('${b.bookingId}')" class="rounded-lg bg-red-50 hover:bg-red-100 text-red-700 px-3 py-1 font-bold tracking-tight text-[10px] cursor-pointer">Cancel</button>
          ` : ''}
          ${b.bookingStatus === 'completed' && !isReviewed ? `
            <button onclick="openReviewModal('${b.artistId}', '${b.bookingId}')" class="rounded-lg bg-violet-600 hover:bg-violet-700 text-white px-3.5 py-1 font-bold text-[10px] cursor-pointer shadow-sm">Review Treatment</button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

window.cancelBooking = function(id) {
  if (!confirm('Are you sure you want to cancel this booking?')) return;
  
  let list = db.getBookings();
  const b = list.find(x => x.bookingId === id);
  if (b) {
    b.bookingStatus = 'cancelled';
    db.saveBookings(list);
    
    // Alert provider
    let alerts = db.getNotifications();
    alerts.push({
      id: 'notif-' + Date.now(),
      userId: b.artistId,
      title: 'Appointment Cancelled',
      message: `${window.user.name} cancelled the booking scheduled on ${b.bookingDate}.`,
      read: false,
      createdAt: new Date().toISOString()
    });
    db.saveNotifications(alerts);

    addToast('Booking successfully cancelled.', 'info');
    renderCustomerBookings();
  }
};

function renderCustomerSaved() {
  const container = document.getElementById('cust-saved-grid');
  const saved = db.getSavedArtists();

  if (saved.length === 0) {
    container.innerHTML = '<p class="text-zinc-400 italic py-4 col-span-2">No bookmarked specialists.</p>';
    return;
  }

  const artists = db.getArtists().filter(a => saved.includes(a.artistId));
  container.innerHTML = artists.map(a => `
    <div onclick="navigateTo('artist-profile', {artistId:'${a.artistId}'})" class="group cursor-pointer border rounded-2xl bg-white p-4.5 dark:bg-zinc-900 border-rose-100/60 dark:border-zinc-805 shadow-sm text-left gap-4 flex transition">
      <img src="${a.portfolio[0] || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150'}" class="h-14 w-14 object-cover rounded-xl" />
      <div class="space-y-1 my-auto">
        <h4 class="font-bold text-sm leading-tight text-zinc-900 dark:text-white group-hover:text-violet-605 transition">${a.name}</h4>
        <p class="text-zinc-405 leading-none">${a.city} &bull; ${a.category}</p>
        <span class="text-[10px] font-bold text-violet-605">Est $${a.pricing}/hr</span>
      </div>
    </div>
  `).join('');
}

function renderCustomerReviews() {
  const container = document.getElementById('cust-reviews-list');
  const list = db.getReviews().filter(r => r.customerId === window.user.id);

  if (list.length === 0) {
    container.innerHTML = '<p class="text-zinc-400 italic py-4">You have not posted any feedback comments yet.</p>';
    return;
  }

  container.innerHTML = list.map(r => {
    const artist = db.getArtists().find(a => a.artistId === r.artistId);
    return `
      <div class="border rounded-2xl p-4.5 bg-white dark:bg-zinc-900 border-rose-105 shadow-sm text-left space-y-1.5 transition-colors">
        <div class="flex justify-between items-center">
          <p class="font-bold">Provider Ref: <span class="text-violet-605 text-xs">${artist?.name || 'Stylist'}</span></p>
          <span class="text-amber-500 font-bold">★ ${r.rating}</span>
        </div>
        <p class="text-zinc-500 leading-normal italic">"${r.comment}"</p>
      </div>
    `;
  }).join('');
}

window.saveCustomerProfile = function(e) {
  e.preventDefault();
  const img = document.getElementById('edit-cust-image').value.trim();
  const name = document.getElementById('edit-cust-name').value.trim();

  let users = db.getUsers();
  const target = users.find(u => u.id === window.user.id);
  if (target) {
    target.profileImage = img;
    target.name = name;
    db.saveUsers(users);

    window.user = target;
    localStorage.setItem('glambook_user', JSON.stringify(target));
    
    addToast('Profile parameters saved successfully!', 'success');
    renderCustomerDashboard();
  }
};

let activeReviewArtistId = '';
let activeReviewBookingId = '';

window.openReviewModal = function(artistId, bookingId) {
  activeReviewArtistId = artistId;
  activeReviewBookingId = bookingId;
  
  document.getElementById('review-rating').value = '5';
  document.getElementById('review-comment').value = '';
  document.getElementById('review-modal').classList.remove('hidden');
};

window.closeReviewModal = function() {
  document.getElementById('review-modal').classList.add('hidden');
};

window.submitReviewForm = function(e) {
  e.preventDefault();
  const rIdx = Number(document.getElementById('review-rating').value);
  const comment = document.getElementById('review-comment').value.trim();

  let reviews = db.getReviews();
  reviews.push({
    reviewId: 'rev-' + Date.now(),
    customerId: window.user.id,
    customerName: window.user.name,
    artistId: activeReviewArtistId,
    rating: rIdx,
    comment,
    createdAt: new Date().toISOString()
  });
  db.saveReviews(reviews);

  // Mark booking completed status explicitly to lock reviewer loop
  let bookings = db.getBookings();
  const b = bookings.find(x => x.bookingId === activeReviewBookingId);
  if (b) {
    b.bookingStatus = 'completed';
    db.saveBookings(bookings);
  }

  addToast('Thank you! Review comments published.', 'success');
  closeReviewModal();
  renderCustomerDashboard();
};

// 16. ARTIST SPECIFICATIONS MANAGER CONSOLE
window.switchArtistTab = function(tab) {
  currentArtistTab = tab;
  
  const ids = ['requests', 'services', 'portfolio', 'profile'];
  ids.forEach(id => {
    const el = document.getElementById('artist-tab-' + id);
    if (!el) return;
    if (id === tab) {
      el.className = 'w-full text-left p-3 rounded-xl font-bold transition flex items-center space-x-2 bg-violet-50 text-violet-750 dark:bg-zinc-805 dark:text-violet-300 cursor-pointer';
    } else {
      el.className = 'w-full text-left p-3 rounded-xl font-bold transition flex items-center space-x-2 hover:bg-slate-50 dark:hover:bg-zinc-850 cursor-pointer';
    }

    const panel = document.getElementById('artist-panel-' + id);
    if (panel) {
      if (id === tab) panel.classList.remove('hidden');
      else panel.classList.add('hidden');
    }
  });

  if (tab === 'requests') renderArtistRequests();
  else if (tab === 'services') renderArtistServices();
  else if (tab === 'portfolio') renderArtistPortfolio();
  else if (tab === 'profile') loadArtistProfileInputs();
};

function renderArtistDashboard() {
  if (!window.user) return;
  const artist = db.getArtists().find(a => a.artistId === window.user.id);
  if (!artist) {
    addToast('Operator logs matching context not configured.', 'error');
    navigateTo('home');
    return;
  }

  document.getElementById('artist-dash-image').src = window.user.profileImage;
  document.getElementById('artist-dash-name').textContent = window.user.name;
  
  if (artist.verified) {
    document.getElementById('artist-dash-verified-badge').classList.remove('hidden');
  } else {
    document.getElementById('artist-dash-verified-badge').classList.add('hidden');
  }
  
  document.getElementById('artist-dash-category').textContent = artist.category + ' specialist';

  // Calculate earnings metrics
  const done = db.getBookings().filter(b => b.artistId === window.user.id && b.bookingStatus === 'completed');
  const sum = done.reduce((acc, curr) => acc + curr.totalAmount, 0);
  document.getElementById('artist-dash-earnings').textContent = '$' + sum;

  const orders = db.getBookings().filter(b => b.artistId === window.user.id);
  document.getElementById('artist-dash-orders').textContent = orders.length + ' reservations';

  switchArtistTab(currentArtistTab);
}

function renderArtistRequests() {
  const container = document.getElementById('artist-requests-list');
  const list = db.getBookings().filter(b => b.artistId === window.user.id);

  if (list.length === 0) {
    container.innerHTML = '<p class="text-zinc-400 italic py-6">Your agenda booking calendar is completely empty.</p>';
    return;
  }

  container.innerHTML = list.map(b => {
    let statCls = 'bg-amber-50 text-amber-700 dark:bg-amber-951/20 dark:text-amber-400';
    if (b.bookingStatus === 'confirmed') statCls = 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-400';
    if (b.bookingStatus === 'completed') statCls = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400';
    if (b.bookingStatus === 'cancelled') statCls = 'bg-red-50 text-red-700 dark:bg-red-955/20 dark:text-red-400';

    return `
      <div class="border rounded-2xl bg-white p-5 dark:bg-zinc-900 border-rose-100/60 dark:border-zinc-805 shadow-sm text-xs relative transition-colors">
        <div class="flex justify-between items-center mb-3">
          <span class="rounded px-2.5 py-0.5 tracking-wider font-extrabold uppercase text-[8px] ${statCls}">${b.bookingStatus}</span>
          <span class="font-black text-rose-600 font-sans">$${b.totalAmount}</span>
        </div>
        <p class="text-sm font-bold font-serif mb-1">${b.serviceName}</p>
        <p class="text-zinc-400">Client profile: <span class="font-bold text-zinc-800 dark:text-zinc-200">${b.customerName}</span></p>
        <p class="text-[10px] text-zinc-400 mt-2">Reserved slot: ${b.bookingDate} at ${b.bookingTime}</p>
        ${b.notes ? `<p class="border-t pt-2 mt-2 font-serif text-[10px] text-zinc-500 italic dark:border-zinc-800">Preferences: "${b.notes}"</p>` : ''}
        
        <div class="mt-4 flex justify-end space-x-2 border-t pt-3 dark:border-zinc-800">
          ${b.bookingStatus === 'pending' ? `
            <button onclick="updateRequestStatus('${b.bookingId}', 'confirmed')" class="rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 px-3 py-1 font-bold text-[10px] cursor-pointer">Confirm</button>
            <button onclick="updateRequestStatus('${b.bookingId}', 'cancelled')" class="rounded-lg bg-red-50 hover:bg-red-100 text-red-705 px-3 py-1 font-bold text-[10px] cursor-pointer">Decline</button>
          ` : ''}
          ${b.bookingStatus === 'confirmed' ? `
            <button onclick="updateRequestStatus('${b.bookingId}', 'completed')" class="rounded-lg bg-violet-600 hover:bg-violet-700 text-white px-3.5 py-1 font-bold text-[10px] cursor-pointer shadow-sm">Mark Accomplished</button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

window.updateRequestStatus = function(bId, status) {
  let list = db.getBookings();
  const b = list.find(x => x.bookingId === bId);
  if (b) {
    b.bookingStatus = status;
    db.saveBookings(list);

    // Dispatch status alert to client
    let alerts = db.getNotifications();
    alerts.push({
      id: 'notif-' + Date.now(),
      userId: b.customerId,
      title: `Booking Update`,
      message: `${window.user.name} marked your appointment scheduled on ${b.bookingDate} as ${status}.`,
      read: false,
      createdAt: new Date().toISOString()
    });
    db.saveNotifications(alerts);

    addToast(`Reservation marked ${status} successfully!`, 'success');
    renderArtistDashboard();
  }
};

function renderArtistServices() {
  const listWrap = document.getElementById('artist-services-list');
  const srvs = db.getServices().filter(s => s.artistId === window.user.id);

  if (srvs.length === 0) {
    listWrap.innerHTML = '<p class="text-zinc-445 italic">No specialized treatments configurations. Publish your first rate treat above.</p>';
    return;
  }

  listWrap.innerHTML = srvs.map(s => `
    <div class="border rounded-xl p-3 px-4 bg-zinc-50/50 flex justify-between items-center dark:bg-zinc-850/50 border-rose-50 dark:border-zinc-800 text-xs transition-colors">
      <div class="text-left">
        <p class="font-bold text-zinc-900 dark:text-white">${s.serviceName}</p>
        <p class="text-[9px] text-zinc-400 mt-0.5">Specialist catalog pricing</p>
      </div>
      <div class="flex items-center space-x-4">
        <span class="font-bold text-violet-655">$${s.price}</span>
        <button onclick="deleteService('${s.serviceId}')" class="text-red-550 font-bold hover:underline cursor-pointer">Remove</button>
      </div>
    </div>
  `).join('');
}

window.submitAddService = function(e) {
  e.preventDefault();
  const name = document.getElementById('add-srv-name').value.trim();
  const price = Number(document.getElementById('add-srv-price').value);

  if (!name || isNaN(price) || price < 10) {
    addToast('Verify inputs details.', 'error');
    return;
  }

  let list = db.getServices();
  list.push({
    serviceId: 'srv-' + Date.now(),
    artistId: window.user.id,
    serviceName: name,
    price
  });
  db.saveServices(list);

  document.getElementById('add-srv-name').value = '';
  document.getElementById('add-srv-price').value = '';

  addToast(`Published rate: "${name}" at $${price}`, 'success');
  renderArtistServices();
};

window.deleteService = function(id) {
  if (!confirm('Are you certain you want to delete this treatment?')) return;
  let list = db.getServices();
  list = list.filter(item => item.serviceId !== id);
  db.saveServices(list);

  addToast('Treatment rate wiped.', 'info');
  renderArtistServices();
};

function renderArtistPortfolio() {
  const artist = db.getArtists().find(a => a.artistId === window.user.id);
  const grid = document.getElementById('artist-portfolio-grid');

  if (artist.portfolio.length === 0) {
    grid.innerHTML = '<p class="text-zinc-400 italic py-4 col-span-3">No images uploaded.</p>';
    return;
  }

  grid.innerHTML = artist.portfolio.map((img, idx) => `
    <div class="aspect-square rounded-2xl relative overflow-hidden group border dark:border-zinc-800 shadow-sm transition">
      <img src="${img}" class="h-full w-full object-cover" />
      <button onclick="deletePortfolioImage(${idx})" class="absolute bottom-2 right-2 bg-black/65 hover:bg-black text-[9px] font-bold text-rose-500 rounded px-2 py-0.5 shadow cursor-pointer">Drop</button>
    </div>
  `).join('');
}

window.submitAddPortfolio = function(e) {
  e.preventDefault();
  const url = document.getElementById('add-portfolio-url').value.trim();
  if (!url) return;

  let artists = db.getArtists();
  const target = artists.find(a => a.artistId === window.user.id);
  if (target) {
    target.portfolio.push(url);
    db.saveArtists(artists);

    document.getElementById('add-portfolio-url').value = '';
    addToast('Gallery artwork uploaded.', 'success');
    renderArtistPortfolio();
  }
};

window.deletePortfolioImage = function(idx) {
  let artists = db.getArtists();
  const target = artists.find(a => a.artistId === window.user.id);
  if (target) {
    target.portfolio.splice(idx, 1);
    db.saveArtists(artists);

    addToast('Artwork dropped.', 'info');
    renderArtistPortfolio();
  }
};

function loadArtistProfileInputs() {
  const artist = db.getArtists().find(a => a.artistId === window.user.id);
  if (!artist) return;

  document.getElementById('edit-artist-category').value = artist.category;
  document.getElementById('edit-artist-city').value = artist.city;
  document.getElementById('edit-artist-exp').value = artist.experience;
  document.getElementById('edit-artist-pricing').value = artist.pricing;
  document.getElementById('edit-artist-bio').value = artist.bio || '';

  const checkboxs = document.querySelectorAll('input[name="edit-artist-avail"]');
  checkboxs.forEach(cb => {
    cb.checked = artist.availability.includes(cb.value);
  });
}

window.saveArtistProfile = function(e) {
  e.preventDefault();
  const cat = document.getElementById('edit-artist-category').value;
  const city = document.getElementById('edit-artist-city').value;
  const exp = Number(document.getElementById('edit-artist-exp').value);
  const pRange = Number(document.getElementById('edit-artist-pricing').value);
  const bio = document.getElementById('edit-artist-bio').value.trim();

  let days = [];
  document.querySelectorAll('input[name="edit-artist-avail"]:checked').forEach(cb => days.push(cb.value));

  let artists = db.getArtists();
  const target = artists.find(a => a.artistId === window.user.id);
  if (target) {
    target.category = cat;
    target.city = city;
    target.experience = exp;
    target.pricing = pRange;
    target.bio = bio;
    target.availability = days;

    db.saveArtists(artists);
    addToast('Biography configuration parameters saved.', 'success');
    renderArtistDashboard();
  }
};

// 17. CENTRAL COMMAND ACCREDITATION OPERATOR HUES
window.switchAdminTab = function(tab) {
  currentAdminTab = tab;
  
  const ids = ['analytics', 'users', 'verifications'];
  ids.forEach(id => {
    const el = document.getElementById('admin-tab-' + id);
    if (!el) return;
    if (id === tab) {
      el.className = 'py-3 px-5 border-b-2 font-bold uppercase tracking-wider shrink-0 transition text-violet-650 border-violet-605 cursor-pointer';
    } else {
      el.className = 'py-3 px-5 border-b-2 font-bold uppercase tracking-wider shrink-0 transition text-zinc-400 border-transparent hover:text-violet-550 cursor-pointer';
    }

    const panel = document.getElementById('admin-panel-' + id);
    if (panel) {
      if (id === tab) panel.classList.remove('hidden');
      else panel.classList.add('hidden');
    }
  });

  if (tab === 'analytics') renderAdminAnalytics();
  else if (tab === 'users') renderAdminUsers();
  else if (tab === 'verifications') renderAdminVerifications();
};

function renderAdminDashboard() {
  if (!window.user || window.user.role !== 'admin') {
    addToast('Administrative access clearance required.', 'error');
    navigateTo('home');
    return;
  }

  // Set counter statistics metrics
  const bookings = db.getBookings();
  const done = bookings.filter(b => b.bookingStatus === 'completed');
  const sumEarnings = done.reduce((acc, curr) => acc + curr.totalAmount, 0);

  document.getElementById('admin-anal-revenue').textContent = '$' + sumEarnings;
  document.getElementById('admin-anal-bookings').textContent = bookings.length;
  document.getElementById('admin-anal-users').textContent = db.getUsers().length;
  document.getElementById('admin-anal-artists').textContent = db.getArtists().length;

  switchAdminTab(currentAdminTab);
}

function renderAdminAnalytics() {
  const container = document.getElementById('admin-analytics-chart-container');
  const catWrap = document.getElementById('admin-analytics-breakdowns-list');

  // Group revenues matching categories
  const categoriesMap = { makeup: 0, mehendi: 0, hairsalon: 0, beautician: 0, photography: 0 };
  const doneBookings = db.getBookings().filter(b => b.bookingStatus === 'completed');
  
  doneBookings.forEach(b => {
    const artist = db.getArtists().find(a => a.artistId === b.artistId);
    if (artist && categoriesMap[artist.category] !== undefined) {
      categoriesMap[artist.category] += b.totalAmount;
    }
  });

  // Calculate high scale values
  const dataset = Object.keys(categoriesMap).map(k => ({ name: k, value: categoriesMap[k] }));
  const maxVal = Math.max(...dataset.map(item => item.value), 200);

  // SVG representation calculation
  const barElements = dataset.map((item, idx) => {
    const percentage = Math.round((item.value / maxVal) * 100);
    const height = Math.max(percentage * 1.5, 6); // Est scales
    const hoverColor = idx % 2 === 0 ? '#ec4899' : '#db2777';
    
    return `
      <div class="flex flex-col items-center flex-1 text-[10px] uppercase font-black tracking-wider text-center">
        <!-- Text metrics -->
        <span class="font-bold text-zinc-900 dark:text-zinc-100">$${item.value}</span>
        <!-- Animated Bar node container style -->
        <div class="w-12 bg-slate-100 dark:bg-zinc-850 rounded-xl relative overflow-hidden flex items-end mt-2" style="height: 150px;">
          <div class="w-full rounded-t-lg transition-all duration-700 hover:opacity-85" style="height: ${percentage}%; background-color: #8b5cf6;"></div>
        </div>
        <span class="text-[9px] text-zinc-400 mt-2 font-mono pb-2">${item.name}</span>
      </div>
    `;
  }).join('');

  container.innerHTML = barElements;

  // Breakdown listings
  catWrap.innerHTML = dataset.map(item => `
    <div class="flex justify-between items-center text-xs pb-1.5 border-b dark:border-zinc-850">
      <span class="capitalize font-bold text-zinc-450">${item.name}:</span>
      <span class="font-black text-rose-605">$${item.value}</span>
    </div>
  `).join('');
}

function renderAdminUsers() {
  const container = document.getElementById('admin-users-table-rows');
  const users = db.getUsers();

  container.innerHTML = users.map(u => `
    <tr class="hover:bg-slate-50/40 dark:hover:bg-zinc-900/40 transition">
      <td class="py-3 flex items-center space-x-2">
        <img src="${u.profileImage}" class="h-8.5 w-8.5 rounded-full object-cover" />
        <span class="font-bold text-zinc-900 dark:text-white">${u.name}</span>
      </td>
      <td class="py-3 font-mono text-[10px] text-zinc-400">${u.email}</td>
      <td class="py-3 font-black text-[9px] uppercase tracking-wider text-pink-700">${u.role}</td>
      <td class="py-3 text-right">
        ${u.role !== 'admin' ? `
          <button onclick="toggleUserBlock('${u.id}')" class="rounded-md px-3 py-1 font-bold tracking-tight text-[10px] cursor-pointer ${
            u.blocked ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700' : 'bg-rose-50 hover:bg-rose-100 text-rose-705'
          }">${u.blocked ? 'Unblock user' : 'Block access'}</button>
        ` : '<span class="text-zinc-400 font-bold">&#128274; Master Role</span>'}
      </td>
    </tr>
  `).join('');
}

window.toggleUserBlock = function(id) {
  let list = db.getUsers();
  const u = list.find(x => x.id === id);
  if (u) {
    u.blocked = !u.blocked;
    db.saveUsers(list);
    addToast('Account security clearance status updated.', 'info');
    renderAdminUsers();
  }
};

function renderAdminVerifications() {
  const container = document.getElementById('admin-verifications-table-rows');
  const artists = db.getArtists();

  container.innerHTML = artists.map(a => `
    <tr class="hover:bg-slate-50/40 dark:hover:bg-zinc-900/40 transition">
      <td class="py-3 flex items-center space-x-2">
        <img src="${a.portfolio[0] || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150'}" class="h-8.5 w-8.5 rounded-full object-cover" />
        <span class="font-bold text-zinc-900 dark:text-white">${a.name}</span>
      </td>
      <td class="py-3 font-mono text-[10px] text-zinc-400 capitalize">${a.city} &bull; ${a.category}</td>
      <td class="py-3 font-bold text-violet-650">$${a.pricing}/hr</td>
      <td class="py-3">
        <span class="rounded px-2 py-0.5 font-bold uppercase text-[9px] ${
          a.verified ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
        }">${a.verified ? 'Verified Active' : 'Pending Review'}</span>
      </td>
      <td class="py-3 text-right">
        <button onclick="toggleArtistVerify('${a.artistId}')" class="rounded-md px-3.5 py-1 font-bold text-[10px] cursor-pointer ${
          a.verified ? 'bg-amber-50 hover:bg-amber-100 text-amber-700' : 'bg-emerald-50 hover:bg-emerald-110 text-emerald-700 shadow-sm'
        }">${a.verified ? 'Revoke Accredited' : 'Endorse Verified'}</button>
      </td>
    </tr>
  `).join('');
}

window.toggleArtistVerify = function(id) {
  let list = db.getArtists();
  const a = list.find(x => x.artistId === id);
  if (a) {
    a.verified = !a.verified;
    db.saveArtists(list);
    addToast('Specialist accreditation status updated.', 'success');
    renderAdminVerifications();
  }
};

// 18. NOTIFICATIONS INBOX INDEX
function renderNotifications() {
  if (!window.user) return;
  const list = db.getNotifications().filter(n => n.userId === window.user.id);

  const empty = document.getElementById('notifications-empty-state');
  const listWrap = document.getElementById('notifications-list');

  if (list.length === 0) {
    empty.classList.remove('hidden');
    listWrap.innerHTML = '';
  } else {
    empty.classList.add('hidden');
    listWrap.innerHTML = list.map(n => `
      <div class="border rounded-2xl p-4 bg-white shadow-sm dark:bg-zinc-900 leading-normal text-left transition relative border-rose-100/60 dark:border-zinc-805 ${
        !n.read ? 'border-l-4 border-l-violet-605 font-bold' : ''
      }">
        <div class="flex justify-between items-center mb-1">
          <p class="font-bold text-zinc-850 dark:text-zinc-150">${n.title}</p>
          <span class="text-[9px] text-zinc-400 font-mono">${new Date(n.createdAt).toLocaleDateString()}</span>
        </div>
        <p class="text-zinc-500 dark:text-zinc-400">${n.message}</p>
      </div>
    `).join('');
  }
}

window.readAllNotifications = function() {
  if (!window.user) return;
  let list = db.getNotifications();
  list.forEach(n => {
    if (n.userId === window.user.id) n.read = true;
  });
  db.saveNotifications(list);
  addToast('Marked all alerts as read.', 'success');
  renderNotifications();
  updateHeaderUI();
};

// 18.5 ABOUT AND CONTACT MODALS INTERACTIVE TRIGGERS
window.showAboutModal = function() {
  const modal = document.getElementById('modal-about');
  if (modal) modal.classList.remove('hidden');
};

window.closeAboutModal = function() {
  const modal = document.getElementById('modal-about');
  if (modal) modal.classList.add('hidden');
};

window.showContactModal = function() {
  const modal = document.getElementById('modal-contact');
  if (modal) modal.classList.remove('hidden');
};

window.closeContactModal = function() {
  const modal = document.getElementById('modal-contact');
  if (modal) modal.classList.add('hidden');
};

window.handleContactSubmit = function(e) {
  e.preventDefault();
  addToast('Your message has been sent successfully! Our support experts will review it shortly.', 'success');
  window.closeContactModal();
  e.target.reset();
};

// 18.8 WORLDWIDE GEOLOCATION ENGINE
function synthesizeArtistsForCity(city) {
  if (!city) return;
  const list = db.getArtists();
  // Case-insensitive check if any artists already exist in this city
  const count = list.filter(a => a.city.toLowerCase() === city.toLowerCase()).length;
  if (count > 0) return;

  // Synthesize 3 world-class specialists for this city
  const categories = ['makeup', 'mehendi', 'hairsalon', 'beautician', 'photography'];
  const firstNames = ['Sophia', 'Isabella', 'Charlotte', 'Amara', 'Fatima', 'Mei', 'Yuki', 'Aria', 'Priya', 'Zara'];
  const lastNames = ['Dupont', 'Smith', 'Patel', 'Al-Mansoori', 'Tanaka', 'Rossi', 'Silva', 'Chen', 'Johnson', 'Nair'];

  const synthesized = [];
  const syntheticUsers = [];
  
  const avatars = [
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', // Sophia
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', // Isabella
    'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150', // Charlotte
    'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150', // Amara
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150'  // Fatima
  ];

  categories.forEach((cat, index) => {
    const fn = firstNames[Math.floor(Math.random() * firstNames.length)];
    const ln = lastNames[Math.floor(Math.random() * lastNames.length)];
    const name = `${fn} ${ln}`;
    const artistId = `synth-${city.toLowerCase().replace(/[^a-z0-9]/g, '')}-${index}`;
    const email = `${fn.toLowerCase()}.${ln.toLowerCase()}@example.com`;
    const profileImg = avatars[index % avatars.length];

    // Synced User model
    syntheticUsers.push({
      id: artistId,
      name: name,
      email: email,
      password: 'password',
      role: 'artist',
      profileImage: profileImg
    });

    synthesized.push({
      artistId: artistId,
      name: name,
      category: cat,
      city: city,
      experience: Math.floor(Math.random() * 8) + 4,
      pricing: Math.floor(Math.random() * 8) * 10 + 90,
      availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      bio: `Elite luxury ${cat} specialist based in ${city} with bridal, fashion, and editorial cosmetics expertise. Now available for calendar booking.`,
      verified: true,
      portfolio: [
        cat === 'makeup' ? 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400' : 
        (cat === 'hairsalon' ? 'https://images.unsplash.com/photo-1562322140-8baeececf3df?w=400' : 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400')
      ]
    });
  });

  // Save both collections to local persistent db safely
  const existingUsers = db.getUsers();
  db.saveUsers([...existingUsers, ...syntheticUsers]);
  db.saveArtists([...list, ...synthesized]);
}

window.detectUserLocation = function(selectId) {
  if (!navigator.geolocation) {
    addToast('Geolocation is not supported by your browser.', 'error');
    return;
  }
  
  addToast('Accessing your coordinates...', 'success');
  navigator.geolocation.getCurrentPosition(async (position) => {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    try {
      const response = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=en`);
      const data = await response.json();
      const city = data.city || data.locality || data.principalSubdivision || 'London';
      
      addToast(`Located: ${city}, ${data.countryName || 'Unknown Country'}!`, 'success');
      
      // Inject this option into all city select dropdowns
      const selectIds = ['home-city-select', 'filter-city', 'signup-city', 'edit-artist-city'];
      selectIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
          let exists = false;
          for (let i = 0; i < el.options.length; i++) {
            if (el.options[i].value.toLowerCase() === city.toLowerCase()) {
              exists = true;
              el.selectedIndex = i;
              break;
            }
          }
          if (!exists) {
            const opt = document.createElement('option');
            opt.value = city;
            opt.textContent = '📍 ' + city;
            el.appendChild(opt);
            el.value = city;
          }
        }
      });
      
      // Ensure synthetic artists exist for this city
      synthesizeArtistsForCity(city);

      // Trigger respective UI actions
      if (selectId === 'home-city-select') {
        const homeSelect = document.getElementById('home-city-select');
        if (homeSelect) homeSelect.value = city;
        handleHomeSearch();
      } else if (selectId === 'filter-city') {
        const filterSelect = document.getElementById('filter-city');
        if (filterSelect) filterSelect.value = city;
        applyFilters();
      }
    } catch (err) {
      console.error(err);
      addToast('Error resolving geographic position. Using IP-backup coordinates.', 'success');
      tryIPLookup(selectId);
    }
  }, (err) => {
    console.warn(err);
    addToast('GPS access denied or timed out inside workspace. Activating premium IP fallback route...', 'info');
    tryIPLookup(selectId);
  }, { timeout: 6000 });
};

async function tryIPLookup(selectId) {
  try {
    const res = await fetch('https://ipapi.co/json/');
    const data = await res.json();
    const city = data.city || 'London';
    
    addToast(`Located via IP connection: ${city}, ${data.country_name || 'Great Kingdom'}!`, 'success');
    
    const selectIds = ['home-city-select', 'filter-city', 'signup-city', 'edit-artist-city'];
    selectIds.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        let exists = false;
        for (let i = 0; i < el.options.length; i++) {
          if (el.options[i].value.toLowerCase() === city.toLowerCase()) {
            exists = true;
            el.selectedIndex = i;
            break;
          }
        }
        if (!exists) {
          const opt = document.createElement('option');
          opt.value = city;
          opt.textContent = '📍 ' + city;
          el.appendChild(opt);
          el.value = city;
        }
      }
    });

    synthesizeArtistsForCity(city);
    
    if (selectId === 'home-city-select') {
      const homeSelect = document.getElementById('home-city-select');
      if (homeSelect) homeSelect.value = city;
      handleHomeSearch();
    } else if (selectId === 'filter-city') {
      const filterSelect = document.getElementById('filter-city');
      if (filterSelect) filterSelect.value = city;
      applyFilters();
    }
  } catch (err) {
    console.error(err);
    addToast('Could not automatically determine position. Please select a premium city directly.', 'error');
  }
}

// 19. RE-BOOT RETAIN INIT STATE
window.onload = function() {
  initTheme();
  
  // Seed database initially
  db.getUsers();
  db.getArtists();
  db.getServices();
  db.getBookings();
  db.getReviews();
  db.getPayments();
  db.getNotifications();
  db.getSavedArtists();

  // Load active view
  navigateTo('home');
};
