# GlamBook MongoDB Schema Specifications (Mongoose models)

This specification defines the production-ready schemas for MongoDB using Mongoose, mapping directly to our client-authoritative state system.

---

## 1. User Schema (`models/User.js`)
```javascript
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  passwordHash: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['client', 'artist', 'admin'],
    default: 'client'
  },
  profileImage: {
    type: String,
    default: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'
  }
}, {
  timestamps: true
});

export const User = mongoose.model('User', userSchema);
```

---

## 2. Artist Profile Schema (`models/Artist.js`)
```javascript
import mongoose from 'mongoose';

const artistSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: true
  },
  city: {
    type: String,
    required: true,
    index: true
  },
  bio: {
    type: String,
    default: ""
  },
  category: {
    type: String,
    enum: ['makeup', 'hairsalon', 'mehendi', 'beautician'],
    required: true,
    index: true
  },
  pricing: {
    type: Number,
    required: true,
    min: 0
  },
  portfolio: [{
    type: String // Cloudinary or S3 CDN image URLs
  }],
  verified: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

// Index to optimize searching keywords by category and location
artistSchema.index({ name: 'text', bio: 'text' });

export const Artist = mongoose.model('Artist', artistSchema);
```

---

## 3. Service Schema (`models/Service.js`)
```javascript
import mongoose from 'mongoose';

const serviceSchema = new mongoose.Schema({
  artistId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Artist',
    required: true
  },
  serviceName: {
    type: String,
    required: true,
    trim: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  duration: {
    type: String, // e.g. "60 min"
    default: "60 mins"
  },
  description: {
    type: String,
    default: ""
  }
}, {
  timestamps: true
});

export const Service = mongoose.model('Service', serviceSchema);
```

---

## 4. Booking Schema (`models/Booking.js`)
```javascript
import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  artistId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Artist',
    required: true
  },
  serviceId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Service',
    required: true
  },
  serviceName: {
    type: String,
    required: true
  },
  artistName: {
    type: String,
    required: true
  },
  bookingDate: {
    type: String, // Formatted as YYYY-MM-DD
    required: true
  },
  bookingTime: {
    type: String, // Formatted as HH:MM
    required: true
  },
  totalAmount: {
    type: Number,
    required: true
  },
  bookingStatus: {
    type: String,
    enum: ['pending', 'confirmed', 'completed', 'cancelled'],
    default: 'pending'
  },
  notes: {
    type: String,
    default: ""
  }
}, {
  timestamps: true
});

export const Booking = mongoose.model('Booking', bookingSchema);
```

---

## 5. Review Schema (`models/Review.js`)
```javascript
import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema({
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true
  },
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  artistId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Artist',
    required: true
  },
  customerName: {
    type: String,
    required: true
  },
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  comment: {
    type: String,
    required: true,
    trim: true
  }
}, {
  timestamps: true
});

export const Review = mongoose.model('Review', reviewSchema);
```

---

## 6. Payment Transaction Schema (`models/Payment.js`)
```javascript
import mongoose from 'mongoose';

const paymentSchema = new mongoose.Schema({
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'successful', 'failed', 'refunded'],
    default: 'pending'
  },
  paymentMethod: {
    type: String,
    default: 'Card'
  }
}, {
  timestamps: true
});

export const Payment = mongoose.model('Payment', paymentSchema);
```
